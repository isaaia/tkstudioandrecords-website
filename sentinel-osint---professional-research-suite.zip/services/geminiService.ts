
import { GoogleGenAI } from "@google/genai";
import { SearchResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const performIntelligenceSearch = async (query: string): Promise<SearchResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Perform a professional OSINT investigation on: "${query}". 
      Focus on extracting publicly available professional contact details (email, public phone numbers) and general office/residency locations. 
      Summarize findings clearly and strictly reference verified public sources.`,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.1, // Low temperature for factual accuracy
      },
    });

    const summary = response.text || "No intelligence data could be summarized.";
    const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const sources = rawChunks
      .filter((chunk: any) => chunk.web)
      .map((chunk: any) => ({
        title: chunk.web.title || "Unknown Source",
        uri: chunk.web.uri,
      }));

    return {
      summary,
      sources,
      timestamp: new Date().toISOString(),
      query,
    };
  } catch (error) {
    console.error("OSINT Retrieval Error:", error);
    throw new Error("Failed to retrieve public intelligence data.");
  }
};
