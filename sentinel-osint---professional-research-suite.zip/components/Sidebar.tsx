
import React from 'react';
import { SearchResult } from '../types';

interface SidebarProps {
  history: SearchResult[];
  onSelect: (result: SearchResult) => void;
  activeId?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ history, onSelect, activeId }) => {
  return (
    <aside className="w-72 bg-[#0c0c0e] border-r border-white/5 flex flex-col">
      <div className="p-6">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4 mono">Intelligence Feed</h3>
        <div className="space-y-2 overflow-y-auto max-h-[calc(100vh-120px)] pr-2">
          {history.length === 0 ? (
            <div className="text-sm text-zinc-600 italic px-2">No active sessions</div>
          ) : (
            history.map((item) => (
              <button
                key={item.timestamp}
                onClick={() => onSelect(item)}
                className={`w-full text-left p-3 rounded-xl transition-all border ${
                  activeId === item.timestamp 
                  ? 'bg-green-500/10 border-green-500/30' 
                  : 'bg-transparent border-transparent hover:bg-white/5 hover:border-white/10'
                }`}
              >
                <div className={`text-sm font-medium truncate ${activeId === item.timestamp ? 'text-green-400' : 'text-zinc-300'}`}>
                  {item.query}
                </div>
                <div className="text-[10px] text-zinc-600 mt-1 mono">
                  {new Date(item.timestamp).toLocaleTimeString()}
                </div>
              </button>
            ))
          )}
        </div>
      </div>
      
      <div className="mt-auto p-6 border-t border-white/5">
        <div className="flex items-center gap-3 p-3 bg-zinc-900/50 rounded-xl border border-zinc-800">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-green-600 to-emerald-400 flex items-center justify-center text-xs font-bold">AN</div>
          <div className="flex-1 overflow-hidden">
            <div className="text-xs font-medium text-white">OSINT_ANALYST</div>
            <div className="text-[10px] text-green-500 uppercase tracking-tighter">Verified Ops</div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
