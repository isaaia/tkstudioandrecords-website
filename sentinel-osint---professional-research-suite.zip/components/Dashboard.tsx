
import React from 'react';
import { SearchResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  result: SearchResult;
}

const Dashboard: React.FC<DashboardProps> = ({ result }) => {
  // Dummy data for visual flair: Source Distribution
  const chartData = [
    { name: 'Social', value: Math.floor(Math.random() * 40) + 10 },
    { name: 'Directory', value: Math.floor(Math.random() * 30) + 10 },
    { name: 'News', value: Math.floor(Math.random() * 20) + 5 },
    { name: 'Gov/Public', value: Math.floor(Math.random() * 15) + 5 },
  ];

  const COLORS = ['#22c55e', '#10b981', '#059669', '#047857'];

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Target Summary Header */}
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-1 bg-[#111114] border border-white/5 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold text-white tracking-tight">Intelligence Report</h2>
            <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-500 rounded-full text-xs mono">
              COMPLETED: {new Date(result.timestamp).toLocaleDateString()}
            </div>
          </div>
          
          <div className="prose prose-invert max-w-none text-zinc-300 leading-relaxed space-y-4">
             {result.summary.split('\n').map((line, i) => (
               <p key={i} className={line.trim() === '' ? 'h-2' : ''}>{line}</p>
             ))}
          </div>
        </div>

        {/* Analytics Side Widget */}
        <div className="w-full md:w-80 space-y-6">
          <div className="bg-[#111114] border border-white/5 rounded-3xl p-6 shadow-xl">
             <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-6 mono">Source Distribution</h4>
             <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                       {chartData.map((entry, index) => (
                         <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                       ))}
                    </Bar>
                    <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                  </BarChart>
                </ResponsiveContainer>
             </div>
          </div>

          <div className="bg-[#111114] border border-white/5 rounded-3xl p-6 shadow-xl">
             <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4 mono">Status Indicators</h4>
             <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">Risk Assessment</span>
                  <span className="text-xs text-zinc-200 font-bold">LOW</span>
                </div>
                <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                  <div className="w-1/4 h-full bg-green-500"></div>
                </div>
                <div className="flex items-center justify-between">
                   <span className="text-xs text-zinc-400">Public Exposure</span>
                   <span className="text-xs text-zinc-200 font-bold">MODERATE</span>
                </div>
                <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                  <div className="w-1/2 h-full bg-yellow-500"></div>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Sources Grid */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest ml-2 mono">Verified Sources & Grounding</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {result.sources.length > 0 ? (
            result.sources.map((source, i) => (
              <a 
                key={i} 
                href={source.uri} 
                target="_blank" 
                rel="noopener noreferrer"
                className="group p-5 bg-[#111114] border border-white/5 rounded-2xl hover:border-green-500/50 hover:bg-white/[0.02] transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-5 h-5 bg-white/5 rounded flex items-center justify-center">
                      <svg className="w-3 h-3 text-zinc-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                      </svg>
                    </div>
                    <span className="text-[10px] text-zinc-500 uppercase tracking-tighter mono">Source Reference</span>
                  </div>
                  <h5 className="text-sm font-semibold text-zinc-200 group-hover:text-green-400 transition-colors line-clamp-2">{source.title}</h5>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-[10px] text-zinc-600 truncate max-w-[150px] mono">{source.uri}</span>
                  <svg className="w-4 h-4 text-zinc-700 group-hover:text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </div>
              </a>
            ))
          ) : (
             <div className="col-span-full p-8 bg-zinc-900/30 border border-dashed border-zinc-800 rounded-3xl text-center text-zinc-500">
                No direct grounding links extracted from this search pass.
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
