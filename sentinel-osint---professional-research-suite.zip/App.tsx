
import React, { useState, useEffect } from 'react';
import { performIntelligenceSearch } from './services/geminiService';
import { SearchResult } from './types';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [activeResult, setActiveResult] = useState<SearchResult | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    try {
      const data = await performIntelligenceSearch(query);
      setResults(prev => [data, ...prev]);
      setActiveResult(data);
      setQuery('');
    } catch (err) {
      alert("Search failed. Ensure your environment is properly configured.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0a0c] overflow-hidden">
      {/* Sidebar for History */}
      <Sidebar 
        history={results} 
        onSelect={setActiveResult} 
        activeId={activeResult?.timestamp} 
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-[#0a0a0c]/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-green-500/20 border border-green-500/40 rounded flex items-center justify-center">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
            </div>
            <span className="font-bold text-lg tracking-tight mono">SENTINEL-v2.5.0</span>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-xs text-zinc-500 px-3 py-1 border border-zinc-800 rounded-full bg-zinc-900/50">
               ENVIRONMENT: <span className="text-green-500">PARROT_LINUX_SIMULATED</span>
             </div>
             <div className="w-2 h-2 rounded-full bg-green-500"></div>
          </div>
        </header>

        {/* Dashboard Display */}
        <div className="flex-1 overflow-y-auto p-8">
          {activeResult ? (
            <Dashboard result={activeResult} />
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-6">
              <div className="p-4 bg-zinc-900/50 rounded-2xl border border-zinc-800">
                <svg className="w-16 h-16 text-zinc-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <h2 className="text-2xl font-semibold mb-2">Ready for Intelligence Retrieval</h2>
                <p className="text-zinc-400">Enter a name, alias, organization, or identifier to begin aggregating public data and location insights.</p>
              </div>
            </div>
          )}
        </div>

        {/* Persistent Search Bar (Sticky Bottom) */}
        <div className="p-6 bg-gradient-to-t from-[#0a0a0c] via-[#0a0a0c] to-transparent">
          <form onSubmit={handleSearch} className="max-w-4xl mx-auto relative group">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter target name, alias, or identifier..."
              className="w-full bg-[#111114] border border-white/10 rounded-2xl py-4 pl-6 pr-32 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all text-white placeholder-zinc-600 shadow-2xl"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading}
              className="absolute right-2 top-2 bottom-2 bg-green-600 hover:bg-green-500 disabled:bg-zinc-800 text-white px-6 rounded-xl font-medium transition-colors flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>SCANNING</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <span>RETRIEVE</span>
                </>
              )}
            </button>
          </form>
          <p className="text-center text-[10px] text-zinc-600 mt-3 mono">SENTINEL OPERATES ON PUBLIC DATA ONLY. ALWAYS ADHERE TO LEGAL AND ETHICAL GUIDELINES.</p>
        </div>
      </main>
    </div>
  );
};

export default App;
