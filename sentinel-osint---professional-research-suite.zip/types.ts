
export interface SearchResult {
  summary: string;
  sources: Array<{
    title: string;
    uri: string;
  }>;
  timestamp: string;
  query: string;
}

export interface ResearchProfile {
  name: string;
  title?: string;
  location?: string;
  contactInfo?: string[];
  socialLinks?: string[];
}
